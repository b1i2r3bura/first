document.addEventListener("DOMContentLoaded", function () {
    const message = document.body.dataset.message;

    if (message === "updated") {
        alert("Report edited successfully.");
    }

    if (message === "deleted") {
        alert("Report deleted successfully.");
    }
});

function confirmDelete() {
    return confirm("Are you sure you want to delete this report?");
}

