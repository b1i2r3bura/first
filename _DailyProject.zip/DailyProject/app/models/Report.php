<?php

class Report
{
    private mysqli $db;

    public function __construct(mysqli $db)
    {
        $this->db = $db;
    }

    public function create(array $data): bool
    {
        $stmt = $this->db->prepare(
            "INSERT INTO reports
            (user_id, superintendent_name, contractor_name, report_date, project_title, total_progress, work_completed, equipment_used, delay_description, additional_remark)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
        );
        $stmt->bind_param(
            "issssdssss",
            $data["user_id"],
            $data["superintendent_name"],
            $data["contractor_name"],
            $data["report_date"],
            $data["project_title"],
            $data["total_progress"],
            $data["work_completed"],
            $data["equipment_used"],
            $data["delay_description"],
            $data["additional_remark"]
        );

        return $stmt->execute();
    }

    public function allByUser(int $userId): array
    {
        $stmt = $this->db->prepare("SELECT * FROM reports WHERE user_id = ? ORDER BY report_date DESC, id DESC");
        $stmt->bind_param("i", $userId);
        $stmt->execute();

        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    public function recent(int $limit = 3): array
    {
        $stmt = $this->db->prepare(
            "SELECT reports.*, users.name AS user_name
            FROM reports
            INNER JOIN users ON users.id = reports.user_id
            ORDER BY reports.created_at DESC
            LIMIT ?"
        );
        $stmt->bind_param("i", $limit);
        $stmt->execute();

        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }

    public function find(int $id, int $userId): ?array
    {
        $stmt = $this->db->prepare("SELECT * FROM reports WHERE id = ? AND user_id = ? LIMIT 1");
        $stmt->bind_param("ii", $id, $userId);
        $stmt->execute();
        $report = $stmt->get_result()->fetch_assoc();

        return $report ?: null;
    }

    public function update(int $id, int $userId, array $data): bool
    {
        $stmt = $this->db->prepare(
            "UPDATE reports SET
                superintendent_name = ?,
                contractor_name = ?,
                report_date = ?,
                project_title = ?,
                total_progress = ?,
                work_completed = ?,
                equipment_used = ?,
                delay_description = ?,
                additional_remark = ?
            WHERE id = ? AND user_id = ?"
        );
        $stmt->bind_param(
            "ssssdssssii",
            $data["superintendent_name"],
            $data["contractor_name"],
            $data["report_date"],
            $data["project_title"],
            $data["total_progress"],
            $data["work_completed"],
            $data["equipment_used"],
            $data["delay_description"],
            $data["additional_remark"],
            $id,
            $userId
        );

        return $stmt->execute();
    }

    public function delete(int $id, int $userId): bool
    {
        $stmt = $this->db->prepare("DELETE FROM reports WHERE id = ? AND user_id = ?");
        $stmt->bind_param("ii", $id, $userId);

        return $stmt->execute();
    }

    public function countByUser(int $userId): int
    {
        $stmt = $this->db->prepare("SELECT COUNT(*) AS total FROM reports WHERE user_id = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();

        return (int) $row["total"];
    }

    public function averageProgressByUser(int $userId): float
    {
        $stmt = $this->db->prepare("SELECT AVG(total_progress) AS average_progress FROM reports WHERE user_id = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();

        return round((float) $row["average_progress"], 2);
    }
}

