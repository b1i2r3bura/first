<?php
$pageTitle = "About Us";
#require_once __DIR__ . "/app/controllers/ReportController.php";
#$reportController = new ReportController();
#$recentReports = $reportController->recent(5);
include(__DIR__ . "/../../includes/header.php"); 
?>
<section class="hero-sectionn">
            
            <h1 style="margin-top :30px; font-size : 35px; margin-left : 50px;">About The System</h1>
            <p  style="max-width: 700px; margin-left: 50px;" class="lead-text">
                Daily Project Progress Report is a high-performance web application engineered for recording, tracking, and managing real-time project site updates within a highly structured relational database infrastructure.
            </p>
        </section>
<section class="specs-grid">
    <div class = "spec-card">
        <div class = "icon-wrapper">
              <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path><polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline><line x1="12" y1="22.08" x2="12" y2="12"></line></svg>
                </div>
                <h3>Architecture</h3>
                <p>Built on a robust, decoupled MVC pattern. Specialized page controllers seamlessly instantiate and manipulate model objects to separate application logic from the presentation layer.</p>
            </div>

            <div class="spec-card">
                <div class="icon-wrapper">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><ellipse cx="12" cy="5" rx="9" ry="3"></ellipse><path d="M3 5V19A9 3 0 0 0 21 19V5"></path><path d="M3 12A9 3 0 0 0 21 12"></path></svg>
                </div>
                <h3>Database Engine</h3>
                <p>Powered by a optimized MySQL relational schema utilizing native MySQLi bindings. Designed with strong relational constraints, storing user account dynamics and linking individual project entries directly to authorized profiles.</p>
            </div>

            <div class="spec-card">
                <div class="icon-wrapper">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>
                </div>
                <h3>Analytical Insights</h3>
                <p>Features real-time reporting metrics. Track immediate performance variations and generate dynamic progress outputs (such as completion percentages) directly from compiled database logs.</p>
            </div>
            <div class="spec-card">
                <div class="icon-wrapper">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"></path><path d="M12 4h9"></path><path d="M4 9h16"></path><path d="M4 15h16"></path></svg>
                </div>
                <h3>Security</h3>
                <p>Implements secure authentication protocols. User credentials are safeguarded with salted hashing, and session management is fortified against common vulnerabilities.</p>
</div>
                
        </section>
    
</section>

<?php include(__DIR__ . "/../../includes/footer.php"); ?>

