<?php
$pageTitle = "View Report | Daily Project Progress Report";
require_once __DIR__ . "/../controllers/UserController.php";
require_once __DIR__ . "/../controllers/ReportController.php";
require_once __DIR__ . "/../../includes/helpers.php";
$userController = new UserController();
$reportController = new ReportController();
$userId = current_user_id();
$id = (int) ($_GET["id"] ?? 0);
$user = $userController->findUser($userId);
$report = $reportController->find($id, $userId);

if (!$user || !$report) {
    header("Location: reports.php?user_id=" . $userId);
    exit;
}

include(__DIR__ . "/../../includes/header.php");
?>

<section class="detail-panel">
    <h1><?php echo h($report["project_title"]); ?></h1>
    <p class="lead">Report date: <?php echo h($report["report_date"]); ?></p>
    <div class="grid">
        <article class="card"><h2>Superintendent</h2><p><?php echo h($report["superintendent_name"]); ?></p></article>
        <article class="card"><h2>Contractor</h2><p><?php echo h($report["contractor_name"]); ?></p></article>
        <article class="card"><h2>Total Progress</h2><p class="stat"><?php echo h($report["total_progress"]); ?>%</p></article>
    </div>
    <div class="grid">
        <article class="card"><h2>Work Completed</h2><p><?php echo nl2br(h($report["work_completed"])); ?></p></article>
        <article class="card"><h2>Equipment Used</h2><p><?php echo nl2br(h($report["equipment_used"])); ?></p></article>
        <article class="card"><h2>Delays</h2><p><?php echo nl2br(h($report["delay_description"])); ?></p></article>
        <article class="card"><h2>Additional Remark</h2><p><?php echo nl2br(h($report["additional_remark"])); ?></p></article>
    </div>
    <div class="actions">
        <a class="button gold" href="report_edit.php?id=<?php echo $id; ?>&user_id=<?php echo $userId; ?>">Edit</a>
        <a class="button" href="reports.php<?php echo user_query(); ?>">Back To Reports</a>
    </div>
</section>

<?php include(__DIR__ . "/../../includes/footer.php"); ?>

