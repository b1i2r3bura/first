<?php
$pageTitle = "Dashboard | Daily Project Progress Report";
require_once __DIR__ . "/../controllers/UserController.php";
require_once __DIR__ . "/../controllers/ReportController.php";
require_once __DIR__ . "/../../includes/helpers.php";
$userController = new UserController();
$reportController = new ReportController();
$userId = current_user_id();
$user = $userController->findUser($userId);

if (!$user) {
    header("Location: login.php");
    exit;
}

$reports = $reportController->allByUser($userId);
$latestReports = array_slice($reports, 0, 5);
include(__DIR__ . "/../../includes/header.php");
?>

<section>
         <h1 style="font-size : 44px; font-weight: 600; font-family: Arial, Helvetica, sans-serif;
 margin-top: 40px; margin-left : 80px;">Dashboard</h1>
    <div class="Dashbord-hero">
        
 <div>
            <p style="margin-right:450px;"> Here's a quick overview of your construction projects and progress reports.</p>
</div>
<div>
    <a class="button primary" href="reports.php<?php echo user_query(); ?>">New Report</a>
</div>
</div>
</section>

<section class="table-panel">
    <h2>Latest Reports</h2>
    
        <table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Project</th>
                    <th>Superintendent</th>
                    <th>Contractor</th>
                    <th>Progress</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($latestReports as $report): ?>
                    <tr>
                        <td><?php echo h($report["report_date"]); ?></td>
                        <td><?php echo h($report["project_title"]); ?></td>
                        <td><?php echo h($report["superintendent_name"]); ?></td>
                        <td><?php echo h($report["contractor_name"]); ?></td>
                        <td><?php echo h($report["total_progress"]); ?>%</td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    
</section>

<?php include(__DIR__ . "/../../includes/footer.php"); ?>

