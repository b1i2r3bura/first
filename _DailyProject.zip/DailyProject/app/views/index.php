<?php
$pageTitle = "Home | Daily Project Progress Report";
#require_once __DIR__ . "/app/controllers/ReportController.php";
 # $reportController = new ReportController();
#$recentReports = $reportController->recent(3);
include(__DIR__ . "/../../includes/header.php");
?>
<section class="newhero">
    <div class="to-fix">
        <h1 class="hero-heading">  
             <span class="dark-blue">Let's </span>
             <span class="bright-blue"> Ease </span>
             <span class="green"> Your </span>
                <span class="orange"> Burden </span>
</h1>
</div>
<div class="newP">
<p>Daily project progress report is a web application that help 
    you to easily submit your daily progress in a structured format. Instead of sending scattered messages or paper notes, you can keep all your reports in one place, making it easier for everyone to follow their progress and to stay organized.
</p>
</div>
<div class="actions">
            <?php if (current_user_id() > 0): ?>
               <a class="button primary" style="margin-left : 260px;" href="reports.php
               <?php echo user_query(); ?>">Get Started</a>
               
               <?php else: ?>
                <a class="button primary" style="margin-left : 260px;" href="register.php">
                    Create Account</a>
                <a class="button" style="margin-left : 20px; color: black;" href="login.php">
                    Login</a>
            <?php endif; ?>
        </div>
               </section>
  <section  class="newhero2">
         <h1 class="h11">Why do you need us?</h1>
       <div class="newcontent2">
        <div>
        <p class="p2"> Manage your business data in one place</p>
        <p class="p2">Track your project progress and performance</p>
        <p class="p2">Make informed decisions based on real-time data</p>
            </div>
<div>
        <img class="img2"  src="assets/images/image3.jpg" alt="Why choose us">
    </div>
         </div>
         <p style="margin-left : 280px; ">
           <a style="color:#817f7f; font-size: 18px; " href="about.php">Learn More --> </a>
       </p>

</section>





<?php include(__DIR__ . "/../../includes/footer.php"); ?>

