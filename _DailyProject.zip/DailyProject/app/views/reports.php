<?php
$pageTitle = "Reports | Daily Project Progress Report";
require_once __DIR__ . "/../controllers/UserController.php";
require_once __DIR__ . "/../controllers/ReportController.php";
require_once __DIR__ . "/../../includes/helpers.php";
$userController = new UserController();
$reportController = new ReportController();
$userId = current_user_id();
$user = $userController->findUser($userId);
$error = "";

if (!$user) {
    header("Location: login.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $error = $reportController->create($_POST);
}

$reports = $reportController->allByUser($userId);
$formAction = "reports.php?user_id=" . $userId;
$submitText = "Save Report";
include(__DIR__ . "/../../includes/header.php");
?>

<section class="form-panel">
    <h1 style ="margin-Top : 40px; font-size : 40px;">Progress Reports</h1>
    <p class="lead">Let's keep track of your project progress!</p>
    <?php if ($error): ?><div class="alert"><?php echo h($error); ?></div><?php endif; ?>
    <?php include(__DIR__ . "/report_form.php"); ?>
</section>

<section class="table-panel">
    <div class="actions">
        <div>
            <h2>All Reports</h2> 
           
        </div>
    </div> 

   
        <table>
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Project</th>
                    <th>Contractor</th>
                    <th>Progress</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($reports as $report): ?>
                    <tr>
                        <td><?php echo h($report["report_date"]); ?></td>
                        <td><?php echo h($report["project_title"]); ?></td>
                        <td><?php echo h($report["contractor_name"]); ?></td>
                        <td><?php echo h($report["total_progress"]); ?>%</td>
                        <td>
                            <div class="row-actions">
                                <a class="button small gold" href="report_edit.php?id=<?php echo $report["id"]; ?>&user_id=<?php echo $userId; ?>">Edit</a>
                                <a class="button small danger" onclick="return confirmDelete();" href="report_delete.php?id=<?php echo $report["id"]; ?>&user_id=<?php echo $userId; ?>">Delete</a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    
</section>

<?php include(__DIR__ . "/../../includes/footer.php"); ?>

