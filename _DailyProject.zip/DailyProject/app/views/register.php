<?php
$pageTitle = "Register | Daily Project Progress Report";
require_once __DIR__ . "/../controllers/UserController.php";
$controller = new UserController();
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $error = $controller->register($_POST);
}

include(__DIR__ . "/../../includes/header.php");
?>

<section class="form-panel">
    
  
    <?php if ($error): ?><div class="alert"><?php echo h($error); ?></div><?php endif; ?>
        <div class="panel">
            <div>
            <h1 style="text-align: center; font-size: 34px;">Create Account</h1>
            
    <form method="post" action="register.php">
        <label>
            Full Name
            <input type="text" name="name" required  placeholder="Enter your name" style=" font-weight: 700; width: 80%;" > 
        </label>
        <label>
            Email Address
            <input type="email" name="email" required maxlength="150" placeholder="Enter your Email" style=" font-weight: 700; width: 80%;" >
        </label>
        <label>
            Password
            <input type="password" placeholder="Enter your password" name="password" required minlength="6" style=" font-weight: 700; width: 80%;" >
        </label>
        <button style="width : 35%;"  class="primary" type="submit">Register</button>
        <a href="login.php" style="margin-left: 20px; font-weight: 700; color: #007BFF;">Already have an account? Login</a>
    </form>
    </div>
    </div>
</section>

<?php include(__DIR__ . "/../../includes/footer.php"); ?>

