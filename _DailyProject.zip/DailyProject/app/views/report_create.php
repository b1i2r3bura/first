<?php
$pageTitle = "Create Report | Daily Project Progress Report";
require_once __DIR__ . "/../controllers/UserController.php";
require_once __DIR__ . "/../controllers/ReportController.php";
require_once __DIR__ . "/../../includes/helpers.php";
$userController = new UserController();
$reportController = new ReportController();
$userId = current_user_id();
$user = $userController->findUser($userId);
$error = "";

if (!$user) {
    header("Location: login.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $error = $reportController->create($_POST);
}

$formAction = "report_create.php?user_id=" . $userId;
$submitText = "Save Report";
include(__DIR__ . "/includes/header.php");
?>

<section class="form-panel">
    <h1>Create Daily Report</h1>
    <p class="lead">Fill in the progress details from the project site.</p>
    <?php if ($error): ?><div class="alert"><?php echo h($error); ?></div><?php endif; ?>
    <?php include(__DIR__ . "/report_form.php"); ?>
</section>

<?php include(__DIR__ . "/../../includes/footer.php"); ?>

