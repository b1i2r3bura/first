<?php
$pageTitle = "Login | Daily Project Progress Report";
require_once __DIR__ . "/../controllers/UserController.php";
$controller = new UserController();
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $error = $controller->login($_POST);
}

include(__DIR__ . "/../../includes/header.php");
?>

<section class="form-panel">
    
    
    <?php if ($error): ?><div class="alert"><?php echo h($error); ?></div><?php endif; ?>
        <div class="panel">
            <div>
            <h1 style="text-align: center; font-size: 34px;">Login</h1>
   
            <form method="post" action="login.php">
        <label>
            Email Address
            <input type="email" name="email" placeholder="Enter your email" required style=" font-weight: 700; width: 80%;" >
        </label>
        <label>
            Password
            <input type="password" name="password" placeholder="Enter your password" minlength="6" style=" font-weight: 700; width: 80%;" required >
        </label>
        <button style ="width: 35%;" class="primary" type="submit">Login</button>
        <a href="register.php" style="margin-left: 20px; font-weight: 700; color: #007BFF;">Don't have an account? Register</a>
    </form>
    </div>
    </div>
</section>

<?php include(__DIR__ . "/../../includes/footer.php"); ?>

