<?php
$pageTitle = "Edit Report | Daily Project Progress Report";
require_once __DIR__ . "/../controllers/UserController.php";
require_once __DIR__ . "/../controllers/ReportController.php";
require_once __DIR__ . "/../../includes/helpers.php";
$userController = new UserController();
$reportController = new ReportController();
$userId = current_user_id();
$id = (int) ($_GET["id"] ?? 0);
$user = $userController->findUser($userId);
$report = $reportController->find($id, $userId);
$error = "";

if (!$user || !$report) {
    header("Location: reports.php?user_id=" . $userId);
    exit;
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $error = $reportController->update($id, $userId, $_POST);
}

$formAction = "report_edit.php?id=" . $id . "&user_id=" . $userId;
$submitText = "Update Report";
include(__DIR__ . "/../../includes/header.php");
?>

<section class="form-panel">
    <h1>Edit Report</h1>
    <p class="lead"><?php echo h($report["project_title"]); ?> for <?php echo h($report["report_date"]); ?></p>
    <?php if ($error): ?><div class="alert"><?php echo h($error); ?></div><?php endif; ?>
    <?php include(__DIR__ . "/report_form.php"); ?>
</section>

<?php include(__DIR__ . "/../../includes/footer.php"); ?>

