<?php
$report = $report ?? [
    "superintendent_name" => "",
    "contractor_name" => "",
    "report_date" => date("Y-m-d"),
    "project_title" => "",
    "total_progress" => "",
    "work_completed" => "",
    "equipment_used" => "",
    "delay_description" => "",
    "additional_remark" => ""
];
?>

<form method="post" action="<?php echo h($formAction); ?>">

    
    <div class="form-grid">
          <input type="hidden" name="user_id" value="<?php echo current_user_id(); ?>">
         <label>
            Your Name
            <input type="text" name="contractor_name" required value="<?php echo h($report["contractor_name"]); ?>">
        </label>
        <label> Project Title
            <input type="text" name="project_title" required value="<?php echo h($report["project_title"]); ?>">
        </label> <br> 
        <label>
             
            Superintendent Name
            <input type="text" name="superintendent_name" required value="<?php echo h($report["superintendent_name"]); ?>">
        </label>
      
        <label>
           Report Date
            <input type="date" name="report_date" required value="<?php echo h($report["report_date"]); ?>">
        </label>
        
        <label>
            Total Progress %
            <input type="number" value="0" name="total_progress" required value="<?php echo h((string) $report["total_progress"]); ?>">
        </label>
    </div>
    <label>
        Work Completed
        <textarea name="work_completed" required><?php echo h($report["work_completed"]); ?></textarea>
    </label>
    <label>
        Equipment Used
        <textarea name="equipment_used"><?php echo h($report["equipment_used"]); ?></textarea>
    </label>
    <label>
        Describe Any Delay
        <textarea name="delay_description" ><?php echo h($report["delay_description"]); ?></textarea>
    </label>
    <label>
        Additional Remark
        <textarea name="additional_remark"><?php echo h($report["additional_remark"]); ?></textarea>
    </label>
    <button class="primary" style="width : 15%" type="submit"><?php echo h($submitText); ?></button>
</form>


