<?php
header("Location: index.php?msg=logout");
exit;

