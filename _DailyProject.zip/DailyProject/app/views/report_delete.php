<?php
require_once __DIR__ . "/../controllers/ReportController.php";
require_once __DIR__ . "/../../includes/helpers.php";
$reportController = new ReportController();
$userId = current_user_id();
$id = (int) ($_GET["id"] ?? 0);

if ($id > 0 && $userId > 0) {
    $reportController->delete($id, $userId);
}

header("Location: reports.php?user_id=" . $userId);
exit;

