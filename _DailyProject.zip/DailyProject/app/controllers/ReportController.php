<?php

require_once __DIR__ . "/../config/Database.php";
require_once __DIR__ . "/../models/Report.php";

class ReportController
{
    private Report $reportModel;

    public function __construct()
    {
        $database = new Database();
        $this->reportModel = new Report($database->connect());
    }

    public function create(array $data): string
    {
        $cleanData = $this->cleanReportData($data);

        if (!$this->isValid($cleanData)) {
            return "Please complete every field and keep total progress between 0 and 100.";
        }

        if ($this->reportModel->create($cleanData)) {
            header("Location: reports.php?user_id=" . $cleanData["user_id"] . "&msg=created");
            exit;
        }

        return "Report could not be saved.";
    }

    public function update(int $id, int $userId, array $data): string
    {
        $cleanData = $this->cleanReportData($data);
        $cleanData["user_id"] = $userId;

        if (!$this->isValid($cleanData)) {
            return "Please complete every field and keep total progress between 0 and 100.";
        }

        if ($this->reportModel->update($id, $userId, $cleanData)) {
            header("Location: reports.php?user_id=" . $userId . "&msg=updated");
            exit;
        }

        return "Report could not be updated.";
    }

    public function delete(int $id, int $userId): void
    {
        $this->reportModel->delete($id, $userId);
        header("Location: reports.php?user_id=" . $userId . "&msg=deleted");
        exit;
    }

    public function allByUser(int $userId): array
    {
        return $this->reportModel->allByUser($userId);
    }

    public function find(int $id, int $userId): ?array
    {
        return $this->reportModel->find($id, $userId);
    }

    public function recent(int $limit = 3): array
    {
        return $this->reportModel->recent($limit);
    }

    public function dashboardStats(int $userId): array
    {
        return [
            "total_reports" => $this->reportModel->countByUser($userId),
            "average_progress" => $this->reportModel->averageProgressByUser($userId)
        ];
    }

    private function cleanReportData(array $data): array
    {
        return [
            "user_id" => (int) ($data["user_id"] ?? 0),
            "superintendent_name" => trim($data["superintendent_name"] ?? ""),
            "contractor_name" => trim($data["contractor_name"] ?? ""),
            "report_date" => trim($data["report_date"] ?? ""),
            "project_title" => trim($data["project_title"] ?? ""),
            "total_progress" => (float) ($data["total_progress"] ?? 0),
            "work_completed" => trim($data["work_completed"] ?? ""),
            "equipment_used" => trim($data["equipment_used"] ?? ""),
            "delay_description" => trim($data["delay_description"] ?? ""),
            "additional_remark" => trim($data["additional_remark"] ?? "")
        ];
    }

    private function isValid(array $data): bool
    {
        return $data["user_id"] > 0
            && $data["superintendent_name"] !== ""
            && $data["contractor_name"] !== ""
            && $data["report_date"] !== ""
            && $data["project_title"] !== ""
            && $data["total_progress"] >= 0
            && $data["total_progress"] <= 100
            && $data["work_completed"] !== ""
            && $data["equipment_used"] !== ""
            && $data["delay_description"] !== ""
            && $data["additional_remark"] !== "";
    }
}

