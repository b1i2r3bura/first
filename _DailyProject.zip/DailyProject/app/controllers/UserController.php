<?php

require_once __DIR__ . "/../config/Database.php";
require_once __DIR__ . "/../models/User.php";

class UserController
{
    private User $userModel;

    public function __construct()
    {
        $database = new Database();
        $this->userModel = new User($database->connect());
    }

    public function register(array $data): string
    {
        $name = trim($data["name"] ?? "");
        $email = trim($data["email"] ?? "");
        $password = $data["password"] ?? "";

        if ($name === "" || !filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($password) < 6) {
            return "Please enter a valid name, email, and password of at least 6 characters.";
        }

        if ($this->userModel->register($name, $email, $password)) {
            $user = $this->userModel->login($email, $password);
            header("Location: dashboard.php?user_id=" . $user["id"]);
            exit;
        }

        return "Registration failed. This email may already be registered.";
    }

    public function login(array $data): string
    {
        $email = trim($data["email"] ?? "");
        $password = $data["password"] ?? "";
        $user = $this->userModel->login($email, $password);

        if ($user) {
            header("Location: dashboard.php?user_id=" . $user["id"]);
            exit;
        }

        return "Invalid email or password.";
    }

    public function findUser(int $id): ?array
    {
        return $this->userModel->findById($id);
    }
}

