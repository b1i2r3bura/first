<?php

class Database
{
    private string $host = "localhost";
    private string $user = "root";
    private string $password = "";
    private string $database = "DailyProject";
    private ?mysqli $connection = null;

    public function connect(): mysqli
    {
        if ($this->connection === null)
             {
            $this->connection = new mysqli( $this->host,  $this->user,  $this->password,  $this->database);

            if ($this->connection->connect_error) {
                die("Database connection failed. Error: " . $this->connection->connect_error);
            }
        }

        return $this->connection;
    }
}


/* class Database {
    private $host;
    private $user;
    private $password;
    private $database;

    public function __construct() {
        $this->host = "localhost";
        $this->user = "root";
        $this->password = "";
        $this->database = "DailyProject";
    }
    public function connect(){

    $connection = new mysqli($this->host, $this->user, $this->password, $this->database);

    if ($connection->connect_error) {
        die("Database connection failed. Error: " . $connection->connect_error);
    }
    else {
        return $connection;
    }
    }
}

*/