<?php

#retrieves the current user id from the http request , query string or form data, and returns it as an integer. If no user id is found, it returns 0. 

# ?? is the null coalescing operator in PHP, which returns the value on its left if it exists and is not null, otherwise it returns the value on its right. In this case, it checks for "user_id" in the $_GET array (query string) and if not found, it checks in the $_POST array (form data). If neither is found, it defaults to 0.
function current_user_id(): int
{
    return (int) ($_GET["user_id"] ?? $_POST["user_id"] ?? 0);
}
 
#  built a url query string based on valid user ID, if the user ID is greater than 0, it returns a query string with the user ID (e.g., "?user_id=12").
function user_query(): string
{
    $userId = current_user_id();
    return $userId > 0 ? "?user_id=" . $userId : "";
}

 # takes a string value and returns a sanitized version of it by converting special characters to their corresponding HTML entities. This is important for preventing cross-site scripting (XSS) attacks when displaying user-generated content on a web page.
function h(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, "UTF-8");
}
# htmlsepcialchars() is a built-in PHP function that converts special characters like (<,>,&...) to HTML entities.
# The ENT_QUOTES flag ensures that both double and single quotes are converted, and "UTF-8" specifies the character encoding to use for the conversion. This function is commonly used to sanitize user input before displaying it on a web page, preventing potential security vulnerabilities. 
#eg: if a user inputs a string like "<script>alert('XSS');</script>", the h() function will convert it to "&lt;script&gt;alert(&#039;XSS&#039;);&lt;/script&gt;", which will be displayed as plain text rather than executing the script. 


