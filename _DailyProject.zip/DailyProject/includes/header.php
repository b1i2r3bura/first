<?php
require_once __DIR__ . "/helpers.php";
$pageTitle = $pageTitle ?? "Daily Project Progress Report";
$userId = current_user_id();
$query = user_query();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo h($pageTitle); ?></title>
    <link rel="stylesheet" href="../../assets/css/style.css">
 
     <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Geist:wght@100..900&display=swap" rel="stylesheet">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    </head>
<body data-message="<?php echo h($_GET["msg"] ?? ""); ?>">
    <header class="site-header">
        <a class="brand" href="index.php<?php echo $query; ?>">
            <span class="brand-mark">DPR</span>
            <span>Daily Project Report</span>
        </a>
        <nav class="main-nav">
            <a href="index.php<?php echo $query; ?>">Home</a>
            <a href="about.php<?php echo $query; ?>">About</a>
            <?php if ($userId > 0): ?>
                <a href="dashboard.php<?php echo $query; ?>">Dashboard</a>
                <a href="reports.php<?php echo $query; ?>">Reports</a>
                <a class="nav-button" href="logout.php">Logout</a>
            <?php else: ?>
                <a href="login.php">Login</a>
                <a class="nav-button" href="register.php">Register</a>
            <?php endif; ?>
        </nav>
    </header>
    <main>

