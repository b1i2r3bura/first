    </main>
    <footer class="site-footer">
       <p>&copy; <?php echo date('Y'); ?>  All rights reserved. </p>
        <div> 

        <?php if (current_user_id() > 0): ?>
             <a style="color : black; "  href="logout.php">Logout</a>
             <?php endif; ?>
        </div>
        
    </footer>
    <script defer src="assets/js/app.js"></script>
</body>
</html>

